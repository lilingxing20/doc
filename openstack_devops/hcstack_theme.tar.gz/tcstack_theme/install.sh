#!/bin/bash

SCRIPTS_DIR=$(cd $(dirname "$0") && pwd)
echo "$SCRIPTS_DIR"

date_str=$(date +%Y%m%d%H%M%S)
backup_dir="/tmp/backup_${date_str}/"

openstack_dashboard_dir='/usr/share/openstack-dashboard/'


# backup
mkdir -p $backup_dir
cp -v ${openstack_dashboard_dir}/openstack_dashboard/static/dashboard/img/favicon.ico $backup_dir
cp -v ${openstack_dashboard_dir}/openstack_dashboard/static/dashboard/img/favicon.ico $backup_dir

# update logo
cp -v ${SCRIPTS_DIR}/favicon.ico ${openstack_dashboard_dir}/openstack_dashboard/static/dashboard/img/
cp -v ${SCRIPTS_DIR}/logo-tcstack.svg ${openstack_dashboard_dir}/openstack_dashboard/static/dashboard/img/
cp -v ${SCRIPTS_DIR}/logo-lucency-tcstack.svg ${openstack_dashboard_dir}/openstack_dashboard/static/dashboard/img/

# patch
cd /
patch -t -b -p1 -i ${SCRIPTS_DIR}/horizon.patch
cd -

# collectstatic & compress
/usr/share/openstack-dashboard/manage.py collectstatic --noinput --clear && /usr/share/openstack-dashboard/manage.py compress --force

# # collectstatic
# cd ${openstack_dashboard_dir}
# python manage.py collectstatic
# cd -
# 
# # compress
# cd ${openstack_dashboard_dir}
# python manage.py compress
# cd -

# restart httpd
systemctl restart httpd
